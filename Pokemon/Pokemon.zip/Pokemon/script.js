$(document).ready(function(){
  $("img")
  var arr = [];
for(var i = 1; i <= 151; i++){
  arr.push(i);
}
  console.log("http://pokeapi.co/media/img/[i].png")

});
