function name(arr) {
  for(var i = 0; i<arr.length; i++){
    console.log(i + " - > " + arr[i]);
  }
}
name(["james", "Jill", "Jane", "Jack"]);
