function range(start, end, increment){
var i = start;
while (i < end){

     console.log(i);
     i = i + increment
}
}
range(2,10,2);
