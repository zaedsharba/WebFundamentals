$(document).ready(function(){

$("#zero").click(function(){
  $(this).attr("src", "img/ninja0.png");

});

$("#one").click(function(){
  $(this).attr("src", "img/ninja1.png");

});

$("#two").click(function(){
  $(this).attr("src", "img/ninja2.png");

});

$("#three").click(function(){
  $(this).attr("src", "img/ninja3.png");

});

$("#four").click(function(){
  $(this).attr("src", "img/ninja4.png");

});

$("#five").click(function(){
  $(this).attr("src", "img/cat0.png");

});

$("#six").click(function(){
  $(this).attr("src", "img/cat1.png");

});

$("#seven").click(function(){
  $(this).attr("src", "img/cat2.png");

});

$("#eight").click(function(){
  $(this).attr("src", "img/cat3.png");

});

$("#nine").click(function(){
  $(this).attr("src", "img/cat4.png");

});

});
